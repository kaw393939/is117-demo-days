# Round 2 — independent repeat and three working products

## Actual steps and findings

1. Re-read the revised short task and SQLite guide. Extracted the **newly regenerated ZIP** into an empty Round 2 directory, verified START-HERE explicitly says Campus Cotton first, and followed that path. This was not a clone of the Round 1 directory. Reused my own attributed budget module after the fresh baseline worked.
2. Repeated the store change/save/restart path. Preserved the corrected published-guide links. The real API check saved $44, reopened it after restart, changed the price to $23, saw a new $46 order without altering the old $44 record, then restored $22.
3. Advanced the group idea into **Campus Bike Desk** using the supplied service-intake pattern. Changed options, labels, scope, receipt text and illustrations. Reviewed Trek, indexed REI page text, and Beargrass primary sources for communication ideas. This is research for a fictional prototype, not proof of local demand or an actual club.
4. Built **Ari's portfolio A/B** linking the actual two local projects and their records. Replaced inherited contribution statements with what was really done and what remains pending. Authored clearly fictional local résumé/GitHub/LinkedIn HTML drafts; no real accounts or credentials were invented.
5. Reviewed readable primary Palantir/Beacon descriptions and produced role cards plus a 250–350-word fictional learner reflection. Maki returned a JavaScript-only shell, so it was not treated as a verified current description. No job application/contact happened.
6. Ran seven behavior/integration checks plus UI syntax check. The actual receipts distinguish borrowed baseline, new changes, machine checks, and unperformed human/course work. Local Git history records real artifact changes.

## Authored learner comments — plausible reactions, not human-study results

- **“The first step is obvious now.”** START-HERE names one example; I no longer wonder whether I must rebuild all six.
- **“I can explain one thing I made.”** The budget message is small enough to understand, and its results are concrete.
- **“The group app can stay small.”** A saved pending request is a useful flow. A booking system would be much larger and is not promised.
- **“I have three things to show.”** The portfolio connects the store and service without claiming a real internship, partner, or customer.
- **“This is still a lot of linked reference material.”** Starting from one class card helps; I should only open another guide when its task needs it.
- **“A working prototype is not all the points.”** I still need actual classmates, recorded feedback/change/retest, real profiles, and my own explanation. An agent cannot manufacture that evidence.

## Round 1 issues and disposition

| Issue | Round 2 result |
| --- | --- |
| Six-example ZIP obscures first action | Guide and ZIP explicitly direct Campus Cotton first; fresh extraction verified |
| Local documentation links point to missing local guide | Source and ZIP use published absolute URLs; source fix verified; root confirmed the portfolio/project/profile path |
| Only one actual working end product | Store, service, and portfolio A/B now exist with linked fictional profile drafts |
| Hypothetical learner reactions could look like real study data | Notes explicitly label authored comments; actual checks have separate receipts |

## Remaining limits and recommended next check

Real student time-on-task, confidence, comprehension and preference are unmeasured. Root confirmed the portfolio links/drafts and a saved pending bike request in the browser; a genuine student trial still matters. The main product/course gaps are actual peer feedback, collaboration, personal accounts/repositories and submission, not more features. Keep them visible rather than adding more templates or quotas.
