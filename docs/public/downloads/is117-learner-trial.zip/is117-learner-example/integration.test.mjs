import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

test('three prototype products serve; real SQLite validates and retains orders/requests across restart',async()=>{
 const dir=await mkdtemp(join(tmpdir(),'is117-round2-'));let child;
 const base='http://127.0.0.1:4208/is117-demo-days/samples/';
 const start=async()=>{child=spawn(process.execPath,['samples/server.mjs'],{env:{...process.env,IS117_DEMO_PORT:'4208',IS117_DEMO_DB:join(dir,'check.sqlite')},stdio:['ignore','pipe','pipe']});await new Promise((resolve,reject)=>{child.stdout.once('data',resolve);child.once('error',reject);child.once('exit',n=>reject(Error('Server exit '+n)))});};
 const stop=async()=>{if(child&&child.exitCode===null){const exited=new Promise(r=>child.once('exit',r));child.kill('SIGTERM');await exited;}child=null};
 const send=async body=>{const r=await fetch(base+'api/records',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)});return {status:r.status,row:await r.json()}};
 const order={project:'campus-cotton',email:'demo@example.test',size:'M',quantity:2,total:0};
 const request={project:'room-ready',email:'demo@example.test',service:'Flat-tire question',window:'Weekday afternoon'};
 const original=await readFile('samples/projects.json','utf8');
 try{
  await start();
  for(const slug of ['campus-cotton','room-ready','maya-chen'])for(const v of ['a','b'])assert.equal((await fetch(base+slug+'/'+v+'.html')).status,200);
  for(const file of ['resume.html','github-profile.html','linkedin.html']){const r=await fetch(base+'maya-chen/'+file);assert.equal(r.status,200);assert.match(await r.text(),/fictional|Fictional/);}
  for(const file of ['shirt-record.txt','group-record.txt','career-reflection.txt'])assert.equal((await fetch(base+'maya-chen/'+file)).status,200);
  for(const file of ['room-ready/concept.svg','maya-chen/concept.svg','budget.js'])assert.equal((await fetch(base+file)).status,200);
  assert.equal((await fetch(base+'api/health').then(r=>r.json())).storage,'sqlite');
  const savedOrder=await send(order);assert.equal(savedOrder.status,201);assert.equal(savedOrder.row.total,44);assert.equal(savedOrder.row.email,undefined);
  const savedRequest=await send(request);assert.equal(savedRequest.status,201);assert.equal(savedRequest.row.status,'Pending confirmation');assert.equal(savedRequest.row.email,undefined);
  assert.equal((await send({...order,quantity:0})).status,400);assert.equal((await send({...order,size:'XL'})).status,400);assert.equal((await send({...request,service:'Unexpected repair'})).status,400);assert.equal((await send({...request,email:'bad'})).status,400);
  await stop();await start();
  const orders=await fetch(base+'api/records?project=campus-cotton').then(r=>r.json());const requests=await fetch(base+'api/records?project=room-ready').then(r=>r.json());
  assert.ok(orders.some(r=>r.reference===savedOrder.row.reference&&r.total===44));assert.ok(requests.some(r=>r.reference===savedRequest.row.reference&&r.status==='Pending confirmation'));
  // Follow the revised guide's small catalog-change check without altering previous orders.
  await stop();const data=JSON.parse(original);data.find(p=>p.slug==='campus-cotton').price=23;await writeFile('samples/projects.json',JSON.stringify(data));await start();
  const newOrder=await send(order);assert.equal(newOrder.status,201);assert.equal(newOrder.row.total,46);
  const old=await fetch(base+'api/records?project=campus-cotton').then(r=>r.json());assert.equal(old.find(r=>r.reference===savedOrder.row.reference).total,44);
  const receipt={checked:'2026-11-03',node:process.version,method:'Actual assistant Node/API/file checks; browser and human review separate',sixABPagesServed:true,threeFictionalProfilePagesServed:true,threeLocalRecordsServed:true,illustrationsAndBudgetModuleServed:true,order:savedOrder.row,request:savedRequest.row,restartRetainedBoth:true,invalidOrderInputsRejected:true,invalidServiceAndEmailRejected:true,falseClientTotalIgnored:true,emailNotSaved:true,catalogChange:{newPrice:23,newOrder:newOrder.row,originalOrderTotal:44,restoredPriceAfterCheck:22},externalDocumentationURLsInSource:true};
  for(const file of ['samples/ui.js','samples/brand-guide.js']){const source=await readFile(file,'utf8');assert.ok(!source.includes('../../examples/submissions/'));assert.ok(source.includes('https://kaw393939.github.io/is117-demo-days/'));}
  await writeFile('test-receipt.json',JSON.stringify(receipt,null,2)+'\n');
 } finally {await stop();await writeFile('samples/projects.json',original);await rm(dir,{recursive:true,force:true})}
});
