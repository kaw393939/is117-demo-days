import { test } from 'node:test';
import assert from 'node:assert/strict';
import { budgetMessage } from './samples/budget.js';
test('two $22 tees leave $6 from the illustrative $50 budget',()=>assert.match(budgetMessage(2,22,50),/^\$6\.00 left/));
test('three tees warn about $16 over budget without blocking a simulated order',()=>assert.match(budgetMessage(3,22,50),/^\$16\.00 over.*still try/));
test('an exact budget is explained accurately',()=>assert.match(budgetMessage(2,25,50),/^Exactly the \$50\.00/));
test('cent arithmetic does not leak floating point values',()=>assert.match(budgetMessage(3,0.1,0.5),/^\$0\.20 left/));
test('invalid quantities do not produce misleading comparisons',()=>{for(const q of [0,-1,1.5,6,NaN])assert.equal(budgetMessage(q,22,50),'')});
test('invalid money inputs do not produce a budget claim',()=>{assert.equal(budgetMessage(2,NaN,50),'');assert.equal(budgetMessage(2,22,-1),'')});
