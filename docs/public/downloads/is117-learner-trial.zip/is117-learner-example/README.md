# Three working IS117 examples — authored learner simulation

This optional teaching packet contains Commuter Cotton, Campus Bike Desk, and Ari's portfolio, each with A/B pages. No real student, peer, partner, accounts, credentials, grades, or Canvas submission. [Attribution](ATTRIBUTION.md) distinguishes provided code from actual adaptations. [Process notes](PROCESS-NOTES.md) distinguish actual checks from fictional learner comments.

## Run locally

1. Install **Node.js 24 or newer**.
2. Extract this ZIP. Open a terminal inside **is117-learner-example**, the folder containing this README and package.json.
3. Run:

```sh
node samples/server.mjs
```

4. Open **http://127.0.0.1:4174/is117-demo-days/samples/maya-chen/a.html** for the portfolio. It links both products, their process records, and explicitly fictional local résumé/GitHub/LinkedIn HTML drafts.
5. Use **Compare version B** on each product to try the alternative. All pairs share data and behavior.
6. Store: select M and quantity 2. Total is $44 with $6 left from the illustrative $50 budget. Complete the synthetic checkout. Group: send a Flat-tire question, weekday afternoon, with demo@example.test. The receipt must say pending, not booked.
7. Copy each reference, stop the server with **Control-C**, rerun the same command, reload, and open history. The references should remain.
8. Stop with **Control-C** when finished. The terminal prints the SQLite path, normally in your system's temporary directory. Product pages and data run locally; guide links open the published course site and need an internet connection.

There are no package dependencies to install. Run **npm test** for seven behavior/integration tests. Its integration check uses a temporary database and restores product data after trying a price change. If another local server already uses port 4174, stop it before starting this one.

## What the three products show

- **Commuter Cotton:** adapted store with $22 unit price, original CC mark, and a small new budget comparison.
- **Campus Bike Desk:** adapted service-intake flow with a topic, preferred window, saved reference, and pending status. No real repairs or bookings.
- **Ari portfolio:** connects the actual two local prototypes, contribution/limit notes, role research, and fictional profile drafts. These drafts do not replace a real student's own accounts.

Records and actual check receipts are included. Real peer feedback, collaboration evidence, professional profiles, public repositories, submission, and instructor assessment remain pending. This is optional example work, not an additional assignment or proof that all course requirements happened.
