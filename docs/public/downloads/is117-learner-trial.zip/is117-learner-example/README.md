# Three working IS117 examples — authored learner simulation

This optional teaching packet contains Commuter Cotton, Campus Bike Desk, and Ari's portfolio, each with A/B pages. No real student, peer, partner, accounts, credentials, grades, or Canvas submission. [Attribution](ATTRIBUTION.md) distinguishes provided code from actual adaptations. [Process notes](PROCESS-NOTES.md) distinguish actual checks from fictional learner comments.

## Try the clickable prototypes

Publish the extracted files on GitHub Pages. Keep prototype-storage.js beside samples.
Open samples/maya-chen/a.html for Ari’s portfolio and links to both product examples.

- Store: choose M and quantity 2. Total $44 leaves $6 in the example budget. Finish a fake checkout.
- Group: save a flat-tire question. The request stays pending.
- Copy each reference. Reload and find it in history. Each browser keeps its own history.

Run npm test to check the budget calculations.

## What the three products show

- **Commuter Cotton:** adapted store with $22 unit price, original CC mark, and a small new budget comparison.
- **Campus Bike Desk:** adapted service-intake flow with a topic, preferred window, saved reference, and pending status. No real repairs or bookings.
- **Ari portfolio:** connects the two browser prototypes, contribution/limit notes, role research, and fictional profile drafts. These drafts do not replace a real student's own accounts.

Project records are included. Real peer feedback, collaboration evidence, professional profiles, public repositories, submission, and instructor assessment remain pending. This is optional example work, not an additional assignment or proof that all course requirements happened.
