# Round 2 — actual technical results

Executed November 3, 2026 using Node **v24.20.0**, from a **fresh extraction of the revised ZIP**. Source ZIP SHA-256: `678418199dee13b5aa925c4efbaecf2c7dd005f1ce4435a7a8d29555322cad5b`.

`npm test`: **7 passed**, 0 failed. Six budget behavior tests plus one integration check covering the three products. `node --check samples/ui.js` also passed.

| Actual check | Result |
| --- | --- |
| All three A/B products | Six HTML pages served successfully |
| Fictional local résumé, GitHub, LinkedIn drafts | Three readable HTML pages served, each labeled fictional |
| Own project/career records | Three local text records served |
| New budget module and original SVG illustrations | Served successfully |
| Shirt order | M × 2 at $22 saved **DEMO-A25E5BD4**, total **$44** |
| Incorrect client total | Submitted 0; server calculated $44 itself |
| Group request | Flat-tire question / weekday afternoon saved **DEMO-F5D2369F**, **Pending confirmation** |
| Input validation | Invalid quantity, size, service, and email rejected |
| Privacy of synthetic email | Validated but absent from saved response |
| Restart | Both order/request references remained in SQLite history |
| Guide's small-change exercise | Changed price to $23, restarted, new order **DEMO-B64C4C6A** totaled **$46**; original remained $44 |
| Restore original prototype | Restored price $22 after checking |
| Local documentation fix | Fresh source uses published absolute guide URLs rather than unavailable local guide paths |

Machine receipt: [test-receipt.json](test-receipt.json). These automated checks used a temporary database that was removed; root's browser preview uses a fresh database. Browser review is separate. Unit/API checks do not prove visual/keyboard/accessibility behavior or a real peer preference.

## Unperformed work

No real peer walkthrough, partner collaboration, GitHub issue/PR, professional account, Canvas submission, instructor grade, or public deployment occurred. No full accessibility/security/performance audit or production-readiness claim. Group and portfolio contain working small products, with those course-evidence gaps explicitly named.

## Root's actual Round 2 browser checks

Root reported CUA verification of the Ari portfolio: contribution/pending labels were readable, links reached the real local projects and records, and résumé/GitHub/LinkedIn links opened fictional HTML drafts. Root then submitted **Flat-tire question / Weekday afternoon / bike@example.test**, receiving **DEMO-EFE3FEF0**, pending desk-volunteer confirmation, with explicit no-booking/no-email language. These are actual assistant browser actions, not human peer or customer evidence.
