# Test the prototypes

Run npm test for the six budget checks. On GitHub Pages, save a demo order or request, copy its reference, reload, and verify it appears again in the same browser.
