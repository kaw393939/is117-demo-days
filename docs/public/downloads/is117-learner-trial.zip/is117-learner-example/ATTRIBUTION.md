# Attribution and boundaries

Actual assistant-authored artifacts for a fictional 18-year-old learner, Ari Chen. No real student, client, partner, peer review, professional account, grade, Canvas submission, or job application.

Fresh baseline: the revised November 3 `is117-example-products.zip`, extracted independently after the Round 1 guide/link fixes. Original course source: https://github.com/kaw393939/is117-demo-days/tree/ad03117339bd469c596c8be5371442fa40969e21/docs/public/samples . The local course revision adds START-HERE and absolute published-documentation links.

The starter supplies the server/SQLite logic, most UI/CSS, existing A/B layout, initial content and shirt concept image. Reused the learner's Round 1 `budget.js` with attribution. New in this round: personalized service data/labels, original bike/process SVGs and monograms, an honest portfolio with actual local project links and contribution limits, three clearly fictional HTML professional drafts, role research, records, and expanded checks. Only `campus-cotton`, `room-ready`, and `maya-chen` were adapted; their original routing slugs remain. Other bundled examples remain references.

All local Git commits are actual commits. No remote issue/PR, peer result, account, partnership, or official grade has been invented. Machine checks and root browser checks are separated from authored learner comments. Group collaboration and actual personal profiles remain unmet requirements for a real student.
