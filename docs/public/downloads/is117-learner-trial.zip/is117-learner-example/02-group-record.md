# Campus Bike Desk — working service prototype

**Authored fictional learner project.** No real partner, club, customer, peer conversation, repair, grade, or Canvas submission. This advances the Round 1 idea using the supplied Room Ready intake code; it is not evidence of completed group collaboration.

## Research and audience

Reviewed primary web sources November 3, 2026:

| Reference | Observation → decision |
| --- | --- |
| [Trek service](https://www.trekbikes.com/us/en_US/service/) | Its process begins with listening/inspection and explains costs before work → tell the visitor what follows a request. |
| [REI bike shop](https://www.rei.com/stores/bike-shop) | Indexed primary-page text lists service categories and location-specific availability. Direct extraction returned mostly footer → avoid copying a universal availability promise. |
| [Beargrass Bicycles](https://www.beargrassbicycles.com/bike-services/) | A detailed service menu ends with a contact route for other needs → offer a small understandable topic menu. Oregon reference, not a Newark competitor. |

These are references for bike-service communication, not three proven direct competitors to an actual campus operation. Trek and REI are broad commercial services; our campus scenario is fictional. No prices, claims of expertise, endorsements, or user demand are transferred.

**Two positions:** welcoming first inquiries from student commuters; or quick repeat inquiries from experienced riders. Choose first inquiries. **Persona A:** commuter unsure which topic to choose, wants to know what happens next, fears accidentally booking a repair. **Persona B:** experienced rider wants fast intake and scope, fears unnecessary steps. Both are hypotheses.

**Brand:** Caregiver; welcoming, specific, honest. A explains scope first; B brings the form forward. Same topics and saved request. Simple aligned structure versus expressive starter geometry. Useful preparation guidance provides value; a welcoming voice may help approachability. Neither proves persuasion.

## Small spec, build, and work split

1. See that this is a fictional inquiry with no diagnosis, repair, or booking.
2. Select a help topic, preferred window, and synthetic email. Empty/unsupported inputs must fail.
3. Receive a reference marked pending; find the same request after restarting SQLite.

Working A/B: `samples/room-ready/a.html` and `b.html`. Kept starter routing identifiers so server code still works. Adapted the real option data, service labels, scope, illustrations, and receipt wording to **Campus Bike Desk**. Added an original bike/request SVG; it does not show a real mechanic or service. Tentatively choose A because the pending/request distinction is introduced early. No actual peer preference was measured.

**Actual work:** the assistant authored all prototype changes and API checks. **Future team agreement:** one member could own service explanation/layout; another validation/history; each reviews the other's work. No imaginary partner's contribution is claimed. Payment, real contacts, notifications, diagnosis, pricing, and scheduling are deferred.

## Checks and limits

See TEST-RESULTS.md for actual valid/invalid request and restart results. Browser/peer review and fair division of actual team work remain pending. A functional app cannot substitute for collaboration evidence. The local customer brief is a possible role-play, not an interview already conducted.
