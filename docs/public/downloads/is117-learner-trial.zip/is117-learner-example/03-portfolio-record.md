# Ari Chen — portfolio A/B and career Research

Ari is an **authored fictional learner**. No real student credentials, personal accounts, employment, peer, partner, grade, or Canvas submission. The three local prototypes and checks are actual artifacts.

## Design plan and built result

**Reader:** an internship mentor or potential small-project supervisor. **Goal:** find two working projects and understand what came from a starter versus what changed. A leads with work; B leads with the introduction and profiles. Both use the same content and links. Tentatively choose A; real peer review remains pending.

**Brand:** Creator; curious, concrete, honest. Plain explanation and inspectable work provide reasons to trust the claim; the short process note offers value. No testimonials or job outcome is invented. The visual directions reuse the classroom starter. A new original diagram shows need → build → check.

**Three checks:** both project links open their correct local apps; contribution notes distinguish provided code/new changes and say collaboration is pending; résumé/GitHub/LinkedIn links open clearly fictional local drafts. Actual profile/repository URLs would be required from a real student. These drafts are teaching content, not substitute accounts.

Built `samples/maya-chen/a.html` and `b.html`; the old path is retained only as a routing identifier. New HTML profile drafts and local project records are linked from the portfolio. It can be inspected without a real identity or external account.

## Career role cards — primary sources checked November 3, 2026

| | Palantir | Beacon Health |
| --- | --- | --- |
| Exact role/source | [Forward Deployed Software Engineer, Internship – Commercial](https://jobs.lever.co/palantir/4d29249a-d7e8-4c39-880d-3b35d7b2f6f6) | [Forward Deployed Engineer Intern](https://www.beaconhealth.ai/team/forward-deployed-engineer-intern) |
| Location/program | NYC onsite; program dates not stated | NYC in-person/hybrid/remote; rolling now, spring/summer 2027 |
| Eligibility | Engineering degree preferred; programming; graduation December 2027 or spring 2028 | Degree enrollment; strong Python/TypeScript/JavaScript foundations; substantial shipped work outside coursework |
| Three tasks, paraphrased | Make design decisions; build customer-specific applications; work with stakeholders | Build automation; check system correctness; own a project through rollout |
| Status/deadline | Listing and Apply link visible; deadline not stated | Page says open role and rolling review; exact deadline not stated |
| Evidence/gap | Small workflow + explanation; fictional freshman's graduation date does not fit this opening | Checked starter adaptation; does not establish substantial independent shipped work |

Maki's page returned a JavaScript-only shell during this round; I used readable Beacon source instead. A page loading does not guarantee future availability. No application was sent.

## Fictional learner reflection — 281 words

I am interested in software work where I can understand why someone needs a tool, build something small, and explain whether it works. I started thinking that a nice-looking page would be the main result. Making the budget message and finding an order after a server restart gave me something more specific to talk about. I can describe what I changed and show a result instead of saying I know every technology.

The two roles are more demanding than these projects. Palantir's customer-specific work sounds creative, but the graduation window does not fit a typical first-year student. Beacon's healthcare setting interests me because mistakes matter, yet my class demo is not suitable for patient information. I should not treat a working form as proof that I can deliver a production system in either setting.

Two connections feel realistic. First, I translated a proposed user concern about spending into a visible budget message. That is a small practice in connecting a need to software. Second, I tested invalid values and checked that a saved record survived restarting the server. That is a beginning in checking a result. The server itself came from the course starter, so I must explain that reuse clearly.

My gaps are listening to actual users and understanding how a secure public application should be deployed and maintained. I also need real experience sharing work with another person. Next week I would ask a classmate to complete the purchase without hints, record one obstacle in a GitHub issue, change the interface, and ask them to retry. I would keep the reflection private and show only suitable project evidence in my portfolio. No one has performed that peer check yet.

**AI use:** AI assisted research extraction, drafting, coding, and checks. Original sources were reviewed; assumptions, eligibility limits, copied code, and unperformed peer work are labeled. This is simulated reflection content, not an actual student's career choice.
