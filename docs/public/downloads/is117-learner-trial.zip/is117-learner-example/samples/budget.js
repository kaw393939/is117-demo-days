// New learner-simulation feature. Advisory only; the server owns actual order totals.
export function budgetMessage(quantity, price, budget) {
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 5 || !Number.isFinite(price) || price < 0 || !Number.isFinite(budget) || budget < 0) return '';
  const total = Math.round(quantity * price * 100);
  const limit = Math.round(budget * 100);
  const dollars = n => new Intl.NumberFormat('en-US', {style:'currency', currency:'USD'}).format(n / 100);
  if (total > limit) return `${dollars(total - limit)} over the ${dollars(limit)} demo budget. You can still try the simulated checkout.`;
  if (total === limit) return `Exactly the ${dollars(limit)} demo budget. No real payment happens.`;
  return `${dollars(limit - total)} left from the ${dollars(limit)} demo budget. No real payment happens.`;
}
