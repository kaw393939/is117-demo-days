# Commuter Cotton — Round 2 Research, Plan, Build, checks

**Fictional learner:** Ari Chen, 18, NJIT commuter. Authored simulation; no actual student or fresh field study. Section 007 task: introduce Nov 3, workshop Nov 5, Research due Nov 10 at 8:30 a.m., 100 points. This local artifact is not a Canvas submission.

## Research

I reused the course's [November 2 Campus Cotton observations](https://kaw393939.github.io/is117-demo-days/examples/submissions/campus-cotton.html#_1-research); I did not revisit these competitors in this round.

| Reference | Existing observation → my decision |
| --- | --- |
| [Fresh Clean Tees](https://freshcleantees.com/products/white-crew-neck) | Fit/length choices; approachable Everyperson reading and displayed reviews → put measurements near size. |
| [True Classic](https://www.trueclassictees.com/products/white-crew-neck-tee) | Several purchase paths, bold comparisons, displayed ratings → keep one price and show the total. |
| [Buck Mason](https://www.buckmason.com/products/white-slub-curved-hem-tee) | Restrained editorial look, specific fabric/production details, Creator reading → show concrete facts without pretending the fictional product is proven. |

**Two positions:** an easy everyday purchase within a student's budget, or a creative outfit starting point. Choose the first; I can address fit and total with one small flow.

**Persona A:** commuter buying a basic tee; wants the right size and a predictable total; worries about fit and spending. **Persona B:** student assembling outfits; wants styling ideas and fabric information; worries about looking generic. Both are untested hypotheses. Website observations do not prove student demand.

**Brand:** Commuter Cotton; Everyperson; plain, calm, practical. “One tee. One clear total.” A uses aligned type and orderly purchase controls; B uses the starter's more expressive composition. Same $22 price, copy, data, and checkout. The flat measurements guide provides useful information (reciprocity); a welcoming voice may support liking. Neither proves conversion. No fake review, urgency, or testimonial.

## Small spec and first build

1. As a shopper, I can find centimeter measurements before selecting M. Check: guide opens beside the selector and the size remains selected.
2. I can compare a purchase with an **illustrative $50 budget**. Check: 2 × $22 = $44, $6 left; 3 × $22 = $66, $16 over. This is advisory, not a checkout restriction.
3. I can complete a labeled synthetic checkout and find the same reference after restarting SQLite. Invalid size/email must not create an order.

Built A/B at `samples/campus-cotton/a.html` and `b.html`, sharing source/data. Provisional choice A: controls are prominent. No claim that people preferred it. Accounts, real payments, shipping, discounts, and real personal data are out of scope.

**New contribution:** changed brand/data/price, drew a CC logo, added and tested `budget.js`, connected it to quantity changes. The classroom starter supplies server/storage and most UI. See [attribution](ATTRIBUTION.md) and [test receipt](TEST-RESULTS.md).

## Feedback and remaining work

No human peer review, GitHub issue, PR, Canvas upload, or official grade occurred. Need a real classmate to find the fit guide, compare A/B, and try the budget message without coaching. Then record the issue, useful change, and actual retest. Public GitHub Pages would use browser storage; this local run uses SQLite. Setup and behavior are checked by code/API, not yet by a real student.

## Round 2 continuation

I started again from the **fresh revised ZIP**, read START-HERE, and followed Campus Cotton first. I reapplied my Round 1 budget module to the fresh UI so the corrected published-documentation links remained. The code/price behavior remains the same small promise; no extra store features were added. All three working prototypes can now be reached from the Ari portfolio. A/B share data, budget, and checkout. Actual checks are in TEST-RESULTS.md. Root's Round 1 browser test confirmed the budget text and a saved order; that is assistant testing, not real peer feedback.
