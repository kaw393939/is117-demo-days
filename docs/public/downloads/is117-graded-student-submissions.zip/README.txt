IS117 — SIX COMPLETED FICTIONAL STUDENT SUBMISSIONS

Start in student-work/: two T-shirt stores, two group businesses, two portfolios.
Each folder contains completed research, two specifications, product comparison,
a peer/change/retest scenario, and rubric scores with instructor feedback.
Section 007 portfolio Research is the career role cards and reflection;
reference-site research and its practice grade in portfolio packets are optional.

These are fictional people and scenario grades, not actual student records.
The peer conversations are invented worked examples, not real interviews.
The separate technical receipt lists checks actually run on the real demo code.

Use the live examples or publish the extracted files on GitHub Pages.
Keep prototype-storage.js beside product-source. These clickable prototypes
save fake orders and requests in the same browser.
Portfolio profile content is completed but fictional; real students use real accounts.

Live guide: https://kaw393939.github.io/is117-demo-days/examples/submissions/
Some links in the Markdown documents use site-relative guide URLs. Use the
published guide for those links or inspect matching product-source files locally.
