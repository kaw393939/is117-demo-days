IS117 — SIX COMPLETED FICTIONAL STUDENT SUBMISSIONS

Start in student-work/: two T-shirt stores, two group businesses, two portfolios.
Each folder contains completed research, two specifications, product comparison,
a peer/change/retest scenario, and rubric scores with instructor feedback.

These are fictional people and scenario grades, not actual student records.
The peer conversations are invented worked examples, not real interviews.
The separate technical receipt lists checks actually run on the real demo code.

To run the products, install Node 24, open a terminal in this extracted folder,
and run: node product-source/server.mjs
Use the printed local URL. The server stores synthetic records in SQLite.
The public versions use browser storage; no actual orders or bookings occur.
Portfolio profile content is completed but fictional; real students use real accounts.

Live guide: https://kaw393939.github.io/is117-demo-days/examples/submissions/
Some links in the Markdown documents use site-relative guide URLs. Use the
published guide for those links or inspect matching product-source files locally.
