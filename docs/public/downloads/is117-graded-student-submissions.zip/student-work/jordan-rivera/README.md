# Jordan Rivera: completed sample submission

**Author:** Jordan Rivera, fictional. **Example type:** Developing example.

**Section 007: required portfolio Research is the [career role cards and reflection](https://kaw393939.github.io/is117-demo-days/examples/career-reflections.html).** Submit it once, privately in Canvas. The reference-site research and its practice score in this packet are optional; they are not a second Research checkpoint.

This folder contains completed research, two website specifications, a two-version product decision, a peer-feedback/change/retest scenario, QA/AI-use notes, and an illustrative instructor assessment. Nothing here is a real student's grade or actual peer interview.

1. [Research](01-research.md)
2. [Specifications](02-specifications.md)
3. [Build and decision](03-build-and-decision.md)
4. [Review and launch](04-review-and-launch.md)
5. [Rubric scores and feedback](ASSESSMENT.md)

**Live versions:** https://kaw393939.github.io/is117-demo-days/samples/jordan-rivera/a.html and https://kaw393939.github.io/is117-demo-days/samples/jordan-rivera/b.html

**Source:** https://github.com/kaw393939/is117-demo-days/tree/main/docs/public/samples. In the full download, the adjacent product-source folder contains the real runnable implementation. From the extracted bundle root, run: node product-source/server.mjs.

Some links in the Markdown documents are site-relative links intended for the published guide. Use the live guide for those links, or inspect the matching product-source files locally. The fictional portfolios use completed local profile examples in place of real personal accounts; real students must use their own actual profile links.
