# Campus Cotton — illustrative instructor assessment

This assesses the fictional submitted record, not a real student. Use the published four-criterion rubric, 25 points per criterion. “Understood” here evaluates the written explanation only; a live class review would also check the student's own explanation.

## 1. Research: 100/100

| Criterion | Points | Evidence and reason |
| --- | --- | --- |
| Complete | 25/25 | Full credit: Three linked references, two positions, two persona cards, and an audience choice are present. |
| Thoughtful | 25/25 | Full credit: The audience choice and brand promise follow a manageable user task and explain why that scope was chosen. |
| Checked | 25/25 | Full credit: The source-to-decision note now names specific reference observations, connects them to the proposed niche or brand decision, and labels the audience need as a hypothesis. |
| Understood | 25/25 | Full credit: The explanation ties the chosen audience to a task and states the limits of the project or reference examples. |

**What worked:** The submission names a plausible audience and keeps claims tied to a small project.

**Optional next step:** ask about a recent real decision in this situation and use the response to refine the hypothesis. Professional market validation is not required for full credit.

[Read the submitted work](01-research.md).

## 2. Plan: 100/100

| Criterion | Points | Evidence and reason |
| --- | --- | --- |
| Complete | 25/25 | Full credit: Two plans, three stories, feature priorities, data/states, and limits are present. |
| Thoughtful | 25/25 | Full credit: The two approaches change hierarchy while holding the offer and task steady. |
| Checked | 25/25 | Full credit: Acceptance checks describe observable behavior for the core task. |
| Understood | 25/25 | Full credit: The plan explains why this scope fits the chosen audience. |

**What worked:** The plan has a manageable core task and avoids a large feature backlog.

**Optional next step:** Reuse these checks while building and update the plan if a decision changes. No extra feature is needed for full credit.

[Read the submitted work](02-specifications.md).

## 3. Build and compare: 98/100

| Criterion | Points | Evidence and reason |
| --- | --- | --- |
| Complete | 25/25 | Full credit: Both working versions and a launch choice are linked. |
| Thoughtful | 25/25 | Full credit: The launch choice uses the stated task and the comparison observations. |
| Checked | 23/25 | Deduction (−2): The A/B notes record finding measurements and choosing a size, but not the quantity and checkout outcome in both versions. |
| Understood | 25/25 | Full credit: The implementation explanation distinguishes the interface, data, and simulation limits. |

**What worked:** A reader can open and compare two real working presentations.

**Next revision:** Record the size, quantity, and checkout outcome for the same task in A and B.

[Read the submitted work](03-build-and-decision.md).

## 4. Get feedback and improve: 98/100

| Criterion | Points | Evidence and reason |
| --- | --- | --- |
| Complete | 25/25 | Full credit: The record includes peer feedback, a change, retest, QA/AI notes, and final links. |
| Thoughtful | 25/25 | Full credit: The change addresses the observed user problem without adding unnecessary scope. |
| Checked | 23/25 | Deduction (−2): The QA record gives no actual keyboard-operation result; saying no full accessibility audit was performed does not record that basic check. |
| Understood | 25/25 | Full credit: The written reflection identifies personal work, AI help, and limits. |

**What worked:** The submission records a specific feedback-driven change rather than a general promise to improve.

**Next revision:** Try the core task using only the keyboard and record the actual result; fix and retest any blocked control.

[Read the submitted work](04-review-and-launch.md).

## Example project score: 99/100

This is an equal average of four milestone scores for comparing the teaching examples. It is not a course grade, letter-grade rule, or new Canvas weighting.

**A more specific explanation to learn from:** I observed fit guides on the reference sites. That suggests sizing information may matter; my persona remains a hypothesis. My peer task checks whether this design makes that information easy to find.

**Brand strategy feedback:** The brief gives a plausible source-to-choice link. Test whether the intended reader understands the promise; do not turn one peer response into a claim about the whole market.
